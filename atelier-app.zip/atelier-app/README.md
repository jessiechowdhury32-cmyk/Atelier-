# Atelier

AI fashion wardrobe app — closet organizer, AI stylist, color analysis,
trend forecasting, and photorealistic virtual try-on.

## What's in this repo

- `src/App.jsx` — the whole app
- `api/claude.js` — keeps your Anthropic API key secret, forwards Closet/Stylist/Colors/Trends requests
- `api/tryon.js` — keeps your FASHN API key secret, runs the virtual try-on

Both `api/` files are serverless functions. Vercel runs these automatically —
you don't need to do anything special to "start" them.

## Deploy to Vercel

1. Push this folder to a GitHub repo (or use the one you already made).
2. Go to vercel.com → Add New → Project → import that repo.
3. Vercel will auto-detect Vite. Leave Build Command, Output Directory, and
   Root Directory on their defaults — they'll now work correctly because
   `package.json` exists.
4. Before deploying, add two Environment Variables:
   - `ANTHROPIC_API_KEY` — from console.anthropic.com
   - `PHOTTA_API_KEY` — from ai.photta.app (Developers tab, "Generate API key")
5. Click Deploy. You'll get a live URL when it finishes.

## Local development (optional)

If you want to test on your own computer first:

```
npm install
npm run dev
```

This runs the app at `http://localhost:5173`, but the `/api/*` functions
won't work locally unless you also run `vercel dev` instead of `npm run dev`
(Vercel's CLI emulates the serverless functions locally too).

## Cost note

Every Closet upload, Stylist request, Color analysis, and Trends check calls
Claude's API — normal per-token pricing applies. Every Try-On generation
calls Photta — 5 credits at 2K resolution, 7 at 4K, per their pricing page.
Neither proxy adds its own markup.

## A note on the Try-On proxy

Photta's `/mannequins/upload` request shape wasn't fully visible in their
public docs when this was written — if the first upload call in
`api/tryon.js` errors, check `api-docs.photta.app` (available once you're
logged into your account) and adjust the field name in that one fetch call.
